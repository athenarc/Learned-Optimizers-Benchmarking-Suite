# PostgreSQL Configuration Variables

Bao can be configured through a number of *session level* PostgreSQL configuration variables. These variables are set to their default values every time you open a session (e.g., `psql` session or a connection from an application).

{{#include pg_vars_table.html}}
