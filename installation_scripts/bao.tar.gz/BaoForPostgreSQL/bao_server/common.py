
class BaoException(Exception):
    pass
