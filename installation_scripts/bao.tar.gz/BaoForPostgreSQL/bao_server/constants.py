PG_OPTIMIZER_INDEX = 0
DEFAULT_MODEL_PATH = "bao_default_model"
TMP_MODEL_PATH = "bao_tmp_model"
OLD_MODEL_PATH = "bao_previous_model"
