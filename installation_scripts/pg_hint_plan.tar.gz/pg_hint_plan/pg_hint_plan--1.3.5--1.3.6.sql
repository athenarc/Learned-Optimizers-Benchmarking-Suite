/* pg_hint_plan/pg_hint_plan--1.3.5--1.3.6.sql */

SELECT pg_catalog.pg_extension_config_dump('hint_plan.hints','');
SELECT pg_catalog.pg_extension_config_dump('hint_plan.hints_id_seq','');
